"""
**DemoPackage**
~~~~~~~~~~~~~~~~~~~
    This is a demo module for the DemoPackage:
        * **Author** - Sourabh Bajaj.
        * **Email** - sourabhbajaj@gatech.edu.
        * **License** - BSD License.
"""

__version__ = '0.0.1'
